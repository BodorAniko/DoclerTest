﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.IO;
using System.Reflection;
using TechTalk.SpecFlow;

namespace ClassLibrary2
{
    [Binding]
    public class stepDefinitions
    {
        //Instance
        PageObject po = new PageObject();
        IWebDriver driver;


        public void setUpBrowser()
        {
            string directory = System.AppDomain.CurrentDomain.BaseDirectory;
            driver = new ChromeDriver(directory);
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
        }

        public void CloseDriver()
        {
            driver.Close();
            //System.Diagnostics.Process.Start("taskkill", "/IM chromedriver.exe /F");
        }

        [Given(@"I'm on the http://uitest\.duodecadits\.com website")]
        public void GivenIMOnTheHttpUitest_Duodecadits_ComWebsite()
        {
            po.NavigateToSite(driver,"http://uitest.duodecadits.com");

        }
        
        [Given(@"I'm on the Form page")]
        public void GivenIMOnTheFormPage()
        {
            po.NavigateToSite(driver, "http://uitest.duodecadits.com/form.html");
        }
        
        [Given(@"I'm on the form page")]
        public void GivenIMOnTheFormPage2()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"I click on the Form menu point")]
        public void WhenIClickOnTheFormMenuPoint(string xpath)
        {
            po.ClickOnButton(driver, xpath);
        }
        
        [When(@"I click on the Error menu point")]
        public void WhenIClickOnTheErrorMenuPoint()
        {
            ScenarioContext.Current.Pending();
        }
        
        [When(@"I click on the Home button")]
        public void WhenIClickOnTheHomeButton(string xpath)
        {
            po.ClickOnButton(driver, xpath);
        }
        
        [When(@"I click on the Form button")]
        public void WhenIClickOnTheFormButton(string xpath)
        {
            po.ClickOnButton(driver, xpath);
        }
        
        [When(@"I click the Error button")]
        public void WhenIClickTheErrorButton(string xpath)
        {
            po.ClickOnButton(driver, xpath);
        }
        
        [When(@"Type a (.*) in the input field")]
        public void WhenTypeAInTheInputField(string xpath, string keysToSend)
        {
            po.Type(driver, xpath, keysToSend);
        }
        
        [Then(@"The title should be ""(.*)""")]
        public void ThenTheTitleShouldBe(string titleFortheSite)
        {
            po.CheckTitle(driver, titleFortheSite);
        }
        
        [Then(@"the company logo should be visible")]
        public void ThenTheCompanyLogoShouldBeVisible(string xpath)
        {
            po.checkElementPresent(driver, xpath);
        }
        
        [Then(@"I should get navigated to the Home page")]
        public void ThenIShouldGetNavigatedToTheHomePage(string url)
        {
            po.CheckUrl(driver, url);
        }
        
        [Then(@"the button should turn into active status")]
        public void ThenTheButtonShouldTurnIntoActiveStatus(string menuItem)
        {
            po.checkElementPresent(driver, menuItem);
        }
        
        [Then(@"I should get navigated to the Form page")]
        public void ThenIShouldGetNavigatedToTheFormPage(string url)
        {
            po.CheckUrl(driver, url);
        }

        
        [Then(@"it should turn into active status")]
        public void ThenItShouldTurnIntoActiveStatus()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"I should get a 404 HTTP response")]
        public void ThenIShouldGetA404HTTPResponse(string response)
        {
            po.CheckTitle(driver, response);
        }
        
        [Then(@"An input box should be visible")]
        public void ThenAnInputBoxShouldBeVisible(string inputField)
        {
            po.checkElementPresent(driver, inputField);
        }

        public void AndASubmitButtonShouldBeVisible(string button)
        {
            po.checkElementPresent(driver, button);
        }

        [Then(@"I click on the UI testing button")]
        public void ThenIClickOnTheUITestingButton(string xpath)
        {
            po.ClickOnButton(driver, xpath);
        }
        
      
        [Then(@"the following text should be visible in (.*) tags: ""(.*)""")]
        public void ThenTheFollowingTextShouldBeVisibleInh1Tags(string xpath)
        {
            po.checkElementPresent(driver, xpath);
        }
        [Then(@"the following text should be visible in (.*) tags: ""(.*)""")]
        public void ThenTheFollowingTextShouldBeVisibleInpTags(string xpath)
        {
            po.checkElementPresent(driver, xpath);
        }

        [Then(@"I should get redirect to the hello page And the following text should appear: (.*)!")]
        public void ThenIShouldGetRedirectToTheHelloPageAndTheFollowingTextShouldAppear(string xpath)
        {
            po.checkElementPresent(driver, xpath);
        }
    }
}
