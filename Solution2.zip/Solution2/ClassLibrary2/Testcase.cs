﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace ClassLibrary2
{
    /*
     * Thread one:
     * Cases ranging from REQ-UI-01 to REQ-UI-06
     */
    [TestFixture]
    [Parallelizable(ParallelScope.Fixtures)]
    class Testcase
    {
        stepDefinitions site = new stepDefinitions();

        [SetUp]
        public void Initialize()
        {
            site.setUpBrowser();
        }
        [Test]
        public void REQ_UI_01_REQ_UI_02()
        {
            site.GivenIMOnTheHttpUitest_Duodecadits_ComWebsite();
            site.WhenIClickOnTheFormMenuPoint("//*[@id=\"form\"]");
            site.ThenTheTitleShouldBe("UI Testing Site");
            site.ThenTheCompanyLogoShouldBeVisible("//*[@id=\"dh_logo\"]");
            site.WhenIClickTheErrorButton("//*[@id=\"error\"]");
            site.ThenTheTitleShouldBe("UI Testing Site");
            site.ThenTheCompanyLogoShouldBeVisible("//*[@id=\"dh_logo\"]");

        }
        [Test]
        public void REQ_UI_03_REQ_UI_04()
        {
            site.GivenIMOnTheHttpUitest_Duodecadits_ComWebsite();
            site.WhenIClickOnTheFormMenuPoint("//*[@id=\"form\"]");
            site.WhenIClickOnTheHomeButton("//*[@id=\"home\"]");
            site.ThenIShouldGetNavigatedToTheHomePage("http://uitest.duodecadits.com/");
            site.ThenTheButtonShouldTurnIntoActiveStatus("//*/*/li[@class=\"active\"]/a[text()=\"Home\"]");
        }

        [Test]
        public void REQ_UI_05_REQ_UI_06()
        {
            site.GivenIMOnTheHttpUitest_Duodecadits_ComWebsite();
            site.WhenIClickOnTheFormMenuPoint("//*[@id=\"form\"]");
            site.ThenIShouldGetNavigatedToTheFormPage("http://uitest.duodecadits.com/form.html");
            site.ThenTheButtonShouldTurnIntoActiveStatus("//*/*/li[@class=\"active\"]/a[text()=\"Form\"]");
        }


        [TearDown]
      public void Endtask()
        {
            site.CloseDriver(); 
        }
    }

    /*
     * Thread two:
     * Cases ranging from REQ-UI-07 to REQ-UI-12
     */
    [TestFixture]
    [Parallelizable(ParallelScope.Fixtures)]
    class Thread2
    {
        stepDefinitions site = new stepDefinitions();

        [SetUp]
        public void Initialize()
        {
            site.setUpBrowser();
        }

        [Test]
        public void REQ_UI_07()
        {
            site.GivenIMOnTheHttpUitest_Duodecadits_ComWebsite();
            site.WhenIClickTheErrorButton("//*[@id=\"error\"]");
            site.ThenIShouldGetA404HTTPResponse("404 Error: File not found :-)");
        }

        [Test]
        public void REQ_UI_08_REQ_UI_11()
        {
            site.GivenIMOnTheFormPage();
            site.ThenAnInputBoxShouldBeVisible("//*[@id=\"hello-input\"]");
            site.AndASubmitButtonShouldBeVisible("//*[@id=\"hello-submit\"]");
            site.ThenIClickOnTheUITestingButton("//*[@id=\"site\"]");
            site.ThenIShouldGetNavigatedToTheHomePage("http://uitest.duodecadits.com/");

        }
        [Test]
        public void REQ_UI_09_REQ_UI_10()
        {
            site.GivenIMOnTheHttpUitest_Duodecadits_ComWebsite();
            site.ThenTheFollowingTextShouldBeVisibleInh1Tags("/html/body/div/div[1]/h1[text()=\"Welcome to the Docler Holding QA Department\"]");
            site.ThenTheFollowingTextShouldBeVisibleInpTags("/html/body/div/div[1]/p[text()=\"This site is dedicated to perform some exercises and demonstrate automated web testing.\"]");

        }

        [Test]
        public void REQ_UI_12()
        {
            site.GivenIMOnTheFormPage();
            site.WhenTypeAInTheInputField("//*[@id=\"hello-input\"]", "John");
            site.WhenIClickOnTheFormButton("//*[@id=\"hello-submit\"]");
            site.ThenIShouldGetRedirectToTheHelloPageAndTheFollowingTextShouldAppear("//*[@id=\"hello-text\" and text()=\"Hello John!\"]");
            site.GivenIMOnTheFormPage();
            site.WhenTypeAInTheInputField("//*[@id=\"hello-input\"]", "Sophia");
            site.WhenIClickOnTheFormButton("//*[@id=\"hello-submit\"]");
            site.ThenIShouldGetRedirectToTheHelloPageAndTheFollowingTextShouldAppear("//*[@id=\"hello-text\" and text()=\"Hello Sophia!\"]");
            site.GivenIMOnTheFormPage();
            site.WhenTypeAInTheInputField("//*[@id=\"hello-input\"]", "Charlie");
            site.WhenIClickOnTheFormButton("//*[@id=\"hello-submit\"]");
            site.ThenIShouldGetRedirectToTheHelloPageAndTheFollowingTextShouldAppear("//*[@id=\"hello-text\" and text()=\"Hello Charlie!\"]");
            site.GivenIMOnTheFormPage();
            site.WhenTypeAInTheInputField("//*[@id=\"hello-input\"]", "Emily");
            site.WhenIClickOnTheFormButton("//*[@id=\"hello-submit\"]");
            site.ThenIShouldGetRedirectToTheHelloPageAndTheFollowingTextShouldAppear("//*[@id=\"hello-text\" and text()=\"Hello Emily!\"]");
        }

        [TearDown]
        public void Endtask()
        {
            site.CloseDriver();
        }
    } 
}
