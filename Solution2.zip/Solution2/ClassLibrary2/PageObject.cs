﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using NUnit.Framework;

namespace ClassLibrary2
{
    class PageObject
    {   /*
        This method is used to navigate to certain sites via the SiteURL parameter.
        */
        public void NavigateToSite(IWebDriver driver, string SiteURL)
        {
            driver.Navigate().GoToUrl(SiteURL);
        }

        /*
        This method is used for clicking on buttons. The parameter is an xpath of the element.
        */
        public void ClickOnButton(IWebDriver driver, string xpath)
        {
            driver.FindElement(By.XPath(xpath)).Click();
        }
        /*
        This method is used for verifying a site's title. Parameter: a string of a certain site's title.
        */
        public void CheckTitle(IWebDriver driver, string title)
        {
            string titlename = driver.Title;
            Boolean isEquals = false;
            if (titlename.Equals(title))
            {
                isEquals = true;
            }
            Assert.IsTrue(isEquals);
        }
        /*
        This method is used for checking if certain elements are displayed on the site. The parameter is an xpath of the element. 
        */
        public void checkElementPresent(IWebDriver driver, string xpath)
        {
            Boolean isDisplayed = driver.FindElement(By.XPath(xpath)).Displayed;
            Assert.IsTrue(isDisplayed);
        }
        /* 
        A method for verifying urls. The parameter is a string of the url to be checked.
         */
       public void CheckUrl(IWebDriver driver, string url)
        {
            string siteurl = driver.Url;
            Boolean isEquals = false;
            if (siteurl.Equals(url))
            {
                isEquals = true;
            }
            Assert.IsTrue(isEquals);
        }
        /*
         This method is used for sending texts into a field. An xpath of the field and the sendable text string are necessary.
        */

        public void Type(IWebDriver driver, string xpath, string keysToSend)
        {
           driver.FindElement(By.XPath(xpath)).SendKeys(keysToSend);
           
        }


    }
}
